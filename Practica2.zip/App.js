import React, { useState, useEffect } from 'react';
import './App.css';

const Note = ({ note, onDelete, onEdit }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedNote, setEditedNote] = useState({ ...note });

  const handleToggleEdit = () => {
    setIsEditing(!isEditing);
    setEditedNote({ ...note });
  };

  const handleSave = () => {
    onEdit(editedNote);
    setIsEditing(false);
  };

  return (
    <div className="note">
      {isEditing ? (
        <div>
          <input
            type="text"
            value={editedNote.title}
            onChange={(e) =>
              setEditedNote({
                ...editedNote,
                title: e.target.value,
              })
            }
          />
          <textarea
            value={editedNote.content}
            onChange={(e) =>
              setEditedNote({
                ...editedNote,
                content: e.target.value,
              })
            }
          ></textarea>
          <button onClick={handleSave}>Guardar</button>
        </div>
      ) : (
        <div>
          <p>{note.title}</p>
          <p>{note.content}</p>
          <button onClick={handleToggleEdit}>Editar</button>
          <button onClick={() => onDelete(note.id)}>Eliminar</button>
        </div>
      )}
    </div>
  );
};

const NoteList = ({ notes, deleteNote, editNote }) => {
  return (
    <div className="note-list">
      {notes.map((note) => (
        <Note
          key={note.id}
          note={note}
          onDelete={deleteNote}
          onEdit={editNote}
        />
      ))}
    </div>
  );
};

const NoteEditor = ({ addNote, notes, editNote, deleteNote }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const handleAddNote = () => {
    if (title.trim() !== '' && content.trim() !== '') {
      addNote({
        id: Date.now(),
        title,
        content,
      });
      setTitle('');
      setContent('');
    }
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const filteredNotes = notes.filter(
    (note) =>
      note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="note-editor">
      <input
        type="text"
        placeholder="Buscar / Filtrar..."
        value={searchTerm}
        onChange={handleSearch}
      />

      <input
        type="text"
        placeholder="Título de nueva nota"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <textarea
        placeholder="Texto de la nueva nota"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      ></textarea>
      <button onClick={handleAddNote}>Crear Nota</button>

      <hr />

      <h3>NOTAS</h3>
      <NoteList notes={filteredNotes} deleteNote={deleteNote} editNote={editNote} />
    </div>
  );
};

const App = () => {
  const [notes, setNotes] = useState([]);

  useEffect(() => {
    const storedNotes = JSON.parse(localStorage.getItem('notes'));
    if (storedNotes) {
      setNotes(storedNotes);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  const addNote = (newNote) => {
    setNotes([...notes, newNote]);
  };

  const deleteNote = (id) => {
    const updatedNotes = notes.filter((note) => note.id !== id);
    setNotes(updatedNotes);
  };

  const editNote = (editedNote) => {
    const updatedNotes = notes.map((note) =>
      note.id === editedNote.id ? editedNote : note
    );
    setNotes(updatedNotes);
  };

  return (
    <div className="app">
      <h1>App Notas</h1>
      <NoteEditor
        addNote={addNote}
        notes={notes}
        editNote={editNote}
        deleteNote={deleteNote}
      />
    </div>
  );
};

export default App;
